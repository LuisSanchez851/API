package co.edu.ue.model3;

import java.io.Serializable;

import jakarta.persistence.*;
import org.locationtech.jts.geom.Point;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import co.edu.ue.controller.PointDeserializer;


/**
 * The persistent class for the estudiantes database table.
 * 
 */
@Entity
@Table(name="estudiantes")
@NamedQuery(name="Estudiante.findAll", query="SELECT e FROM Estudiante e")
public class Estudiante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="estu_cedula")
	private int estuCedula;

	@Column(name="estu_apellido")
	private String estuApellido;

	@Column(name="estu_nombre")
	private String estuNombre;

	@Column(name="estu_residencia")
	private String estuResidencia;

	@Column(name="estu_trabajo")
	private String estuTrabajo;
	@JsonDeserialize(using = PointDeserializer.class)
	@Column(name="estu_ubi_residencia", columnDefinition = "geometry(Point, 4326)")
	private Point estuUbiResidencia;
	@JsonDeserialize(using = PointDeserializer.class)
	@Column(name="estu_ubi_trabajo", columnDefinition = "geometry(Point, 4326)")
	private Point estuUbiTrabajo;

	public Estudiante() {
	}

	public int getEstuCedula() {
		return this.estuCedula;
	}

	public void setEstuCedula(int estuCedula) {
		this.estuCedula = estuCedula;
	}

	public String getEstuApellido() {
		return this.estuApellido;
	}

	public void setEstuApellido(String estuApellido) {
		this.estuApellido = estuApellido;
	}

	public String getEstuNombre() {
		return this.estuNombre;
	}

	public void setEstuNombre(String estuNombre) {
		this.estuNombre = estuNombre;
	}

	public String getEstuResidencia() {
		return this.estuResidencia;
	}

	public void setEstuResidencia(String estuResidencia) {
		this.estuResidencia = estuResidencia;
	}

	public String getEstuTrabajo() {
		return this.estuTrabajo;
	}

	public void setEstuTrabajo(String estuTrabajo) {
		this.estuTrabajo = estuTrabajo;
	}

	 public Point getEstuUbiResidencia() {
	        return estuUbiResidencia;
	    }

	    public void setEstuUbiResidencia(Point estuUbiResidencia) {
	        this.estuUbiResidencia = estuUbiResidencia;
	    }

	    public Point getEstuUbiTrabajo() {
	        return estuUbiTrabajo;
	    }

	    public void setEstuUbiTrabajo(Point estuUbiTrabajo) {
	        this.estuUbiTrabajo = estuUbiTrabajo;
	    }

}