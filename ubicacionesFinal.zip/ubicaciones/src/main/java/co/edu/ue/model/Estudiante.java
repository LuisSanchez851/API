package co.edu.ue.model;

import java.io.Serializable;


import jakarta.persistence.*;


/**
 * The persistent class for the estudiantes database table.
 * 
 */
@Entity
@Table(name="estudiantes")
@NamedQuery(name="Estudiante.findAll", query="SELECT e FROM Estudiante e")
public class Estudiante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="estu_cedula")
	private int estuCedula;
	
	@Column(name="estu_apellido")
	private String estuApellido;

	@Column(name="estu_latitud_residencia")
	private double estuLatitudResidencia;

	@Column(name="estu_latitud_trabajo")
	private double estuLatitudTrabajo;

	@Column(name="estu_longitud_residencia")
	private double estuLongitudResidencia;

	@Column(name="estu_longitud_trabajo")
	private double estuLongitudTrabajo;

	@Column(name="estu_nombre")
	private String estuNombre;

	@Column(name="estu_residencia")
	private String estuResidencia;

	@Column(name="estu_trabajo")
	private String estuTrabajo;
	


	public Estudiante() {
	}

	public String getEstuApellido() {
		return this.estuApellido;
	}

	public void setEstuApellido(String estuApellido) {
		this.estuApellido = estuApellido;
	}

	public int getEstuCedula() {
		return this.estuCedula;
	}

	public void setEstuCedula(int estuCedula) {
		this.estuCedula = estuCedula;
	}

	public double getEstuLatitudResidencia() {
		return this.estuLatitudResidencia;
	}

	public void setEstuLatitudResidencia(double estuLatitudResidencia) {
		this.estuLatitudResidencia = estuLatitudResidencia;
	}

	public double getEstuLatitudTrabajo() {
		return this.estuLatitudTrabajo;
	}

	public void setEstuLatitudTrabajo(double estuLatitudTrabajo) {
		this.estuLatitudTrabajo = estuLatitudTrabajo;
	}

	public double getEstuLongitudResidencia() {
		return this.estuLongitudResidencia;
	}

	public void setEstuLongitudResidencia(double estuLongitudResidencia) {
		this.estuLongitudResidencia = estuLongitudResidencia;
	}

	public double getEstuLongitudTrabajo() {
		return this.estuLongitudTrabajo;
	}

	public void setEstuLongitudTrabajo(double estuLongitudTrabajo) {
		this.estuLongitudTrabajo = estuLongitudTrabajo;
	}

	public String getEstuNombre() {
		return this.estuNombre;
	}

	public void setEstuNombre(String estuNombre) {
		this.estuNombre = estuNombre;
	}

	public String getEstuResidencia() {
		return this.estuResidencia;
	}

	public void setEstuResidencia(String estuResidencia) {
		this.estuResidencia = estuResidencia;
	}

	public String getEstuTrabajo() {
		return this.estuTrabajo;
	}

	public void setEstuTrabajo(String estuTrabajo) {
		this.estuTrabajo = estuTrabajo;
	}

	

}